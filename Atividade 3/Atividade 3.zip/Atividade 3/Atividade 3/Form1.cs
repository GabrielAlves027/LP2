﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_3
{
    public partial class Form1 : Form
    {
        double peso, altura, IMC;
        public Form1()
        {
            InitializeComponent();
        }

        private void Label1_Click(object sender, EventArgs e)
        {

        }

        private void TxtIMC_Validated(object sender, EventArgs e)
        {
            
        }

        private void MskbxAltura_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {
            errorProvider2.SetError(mskbxAltura, "");
            if (!double.TryParse(mskbxAltura.Text, out altura) || (altura<=0))
            {
                MessageBox.Show("Altura inválida!");
                errorProvider2.SetError(mskbxAltura, "Altura inválida");
            }
        }

        private void BtnCalcular_Click(object sender, EventArgs e)
        {
            if (Double.TryParse(mskbxAltura.Text, out altura) && Double.TryParse(mskbxPeso.Text, out peso))
            {
                if ((altura <= 0) || (peso <= 0))
                {
                    MessageBox.Show("Valores devem ser maiores que zero!");
                }
                else
                {
                    IMC = peso / Math.Pow(altura, 2);
                    IMC = Math.Round(IMC, 1);
                    if (IMC < 18.5)
                    {
                        txtIMC.Text = "Magreza: " + IMC.ToString();
                    }
                    else
                    {
                        if (IMC <= 24.9)
                        {
                            txtIMC.Text = "Normal: " + IMC.ToString();
                        }
                        else
                        {
                            if (IMC <= 29.9)
                            {
                                txtIMC.Text = "Sobrepeso: " + IMC.ToString();
                            }
                            else
                            {
                                if (IMC <= 39.9)
                                {
                                    txtIMC.Text = "Obesidade: " + IMC.ToString();
                                }
                                else
                                    txtIMC.Text = "Obesidade grave: " + IMC.ToString();
                            }
                        }
                    }
                }
            }
        }

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            mskbxAltura.Text = "";
            mskbxPeso.Text = "";
            txtIMC.Text = "";
        }

        private void Form1_Validated(object sender, EventArgs e)
        {

        }

        private void MskbxPeso_Validated(object sender, EventArgs e)
        {
            errorProvider1.SetError(mskbxPeso, "");
            if (!double.TryParse(mskbxPeso.Text, out peso) || (peso<=0))
            {
                MessageBox.Show("Peso inválido!");
                errorProvider1.SetError(mskbxPeso, "Peso inválido");
            }
        }
    }
}

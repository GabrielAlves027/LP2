﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace Atividade8
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btnExecutar_Click(object sender, EventArgs e)
        {
            string nomes = "";
            int n = 0;
            int n1 = 0;

            while (true)
            {
                nomes = Interaction.InputBox("Digite o último dígito do seu RA");
                if (int.TryParse(nomes, out n))
                {
                    break;

                }
                else

                    MessageBox.Show("Número inválido. Tente novamente.");
            }

            if (n == 0)
            {
                n1 = 10;

            }
            else
            {
                n1 = n;
            }

            string[] aux = new string[n1];

            for (var i = 0; i < n1; i++)
            {
                aux[i] = Interaction.InputBox("Digite os nomes");
            }

            lstbxNomes.Items.Clear();

            for (var i = 0; i < n1; i++)
            {
                if (!string.IsNullOrEmpty(aux[i]))
                {

                    int count = aux[i].Replace(" ", "").Length;
                    lstbxNomes.Items.Add($"O nome: {aux[i]} tem {count} caracteres.");
                }

            }
        }
    }
}

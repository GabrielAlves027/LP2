﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;
using System.Collections;

namespace Atividade8
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnEx1_Click(object sender, EventArgs e)
        {
            int[] vetor = new int[20];
            string auxiliar = "";
            string saida = "";

            for (var i = 0; i < 20; i++)
            {
                auxiliar = Interaction.InputBox("Digite um nº", "Entrada de Dados");
                if (!int.TryParse(auxiliar, out vetor[i]))
                {
                    MessageBox.Show("Número inválido!");
                    i--;
                }
                else
                {
                    saida = vetor[i] + "\n" + saida;
                }
            }
            MessageBox.Show(saida);
            /*
            auxiliar = "";

            for (var j=19; j>=0; j--)
            {
                auxiliar += vetor[j]+"\n";
            }

            MessageBox.Show(auxiliar);
            */

            // mostrar usando o reverse
            Array.Reverse(vetor);

            auxiliar = "";

            foreach (var c in vetor)
                auxiliar += c + "\n";

            MessageBox.Show(auxiliar);


        }

        private void BtnEx2_Click(object sender, EventArgs e)
        {
            Double[,] notas = new Double[20,3];
            double media = 0;
            double auxmedia = 0;
            string auxiliar = "";

            for (var i = 0; i < 20; i++)
            {
                media = 0;
                auxmedia = 0;
                for (var j = 0; j < 3; j++)
                {
                    auxiliar = Interaction.InputBox("Insira as notas:", "Entrada de Dados");
                    if (!Double.TryParse(auxiliar, out notas[i, j]) || notas[i,j]<0 || notas[i,j]>10)
                    {
                        MessageBox.Show("Número inválido!");
                        j--;
                    }
                    else
                    {
                        media = notas[i, j];
                    }
                    auxmedia = auxmedia + media;
                }
                media = auxmedia / 3;
                MessageBox.Show("\nAluno " + (i + 1) + ": " + media);
            }
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnEx3_Click(object sender, EventArgs e)
        {
            string[] Alunos = {"Viviane", "André", "Hélio", "Denise", "Junior", "Leonardo", "Jose", "Nelma", "Tobby"};
            Int32 N = Alunos.Length;
            Int32 I, Total = 0;
            for (I = 0; I < N - 1; I++)
            {
                Total += Alunos[I].Length;
            }
            MessageBox.Show(Total.ToString());
        }

        private void btnEx4_Click(object sender, EventArgs e)
        {
            ArrayList nomes = new ArrayList();
            nomes.Add("Ana");
            nomes.Add("André");
            nomes.Add("Débora");
            nomes.Add("Fátima");
            nomes.Add("João");
            nomes.Add("Janete");
            nomes.Add("Otávio");
            nomes.Add("Marcelo");
            nomes.Add("Pedro");
            nomes.Add("Thais");

            nomes.Remove("Otávio");
            foreach (string lista in nomes)
            {
                MessageBox.Show(lista);
            }
        }

        private void btnEx5_Click(object sender, EventArgs e)
        {
            Form2 newForm2 = new Form2();
            newForm2.ShowDialog();
        }
    }
}

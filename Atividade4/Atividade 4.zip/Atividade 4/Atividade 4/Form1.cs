﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Atividade_4
{
    public partial class Form1 : Form
    {
        double ladoA, ladoB, ladoC;
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void txtLadoB_Validated(object sender, EventArgs e)
        {
            Double.TryParse(txtLadoB.Text, out ladoB);
        }

        private void txtLadoC_Validated(object sender, EventArgs e)
        {
            Double.TryParse(txtLadoC.Text, out ladoC);
        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            if ((ladoA <= 0) || (ladoB <= 0) || (ladoC <= 0))
                MessageBox.Show("Não existe lado menor ou igual a 0!");
            else
            {
                if ((Math.Abs(ladoB - ladoC)) < (ladoA) && (ladoA) < (ladoB + ladoC) && (Math.Abs(ladoA - ladoC)) < (ladoB) && (ladoB) < (ladoA + ladoC) && (Math.Abs(ladoA - ladoB)) < (ladoC) && (ladoC) < (ladoA + ladoB))
                {
                    if ((Math.Abs(ladoA - ladoB)) < (ladoC) && (ladoC) < (ladoA + ladoB))
                    {
                        if (ladoA == ladoB && ladoA == ladoC && ladoB == ladoC)
                            txtTriangulo.Text = "Triângulo equilátero";
                        else
                        {
                            if (ladoA != ladoB && ladoA != ladoC && ladoB != ladoC)
                                txtTriangulo.Text = "Triânuglo escaleno";
                            else
                                txtTriangulo.Text = "Triângulo isósceles";
                        }
                    }
                }
                else
                    txtTriangulo.Text = "Não é um triângulo válido";
            }
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLadoA.Text = "";
            txtLadoB.Text = "";
            txtLadoC.Text = "";
            txtTriangulo.Text = "";
        }

        private void txtLadoA_Validated(object sender, EventArgs e)
        {
            Double.TryParse(txtLadoA.Text, out ladoA);
        }
    }
}

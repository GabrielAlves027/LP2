﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.VisualBasic;

namespace PVendas
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            Double [,] periodo = new Double[3,4];
            string auxiliar = "";
            int i, j;
            Double mes = 0;
            Double geral = 0;

            for (i = 0; i < 3; i++)
            {
                mes = 0;

                for(j = 0; j < 4; j++)
                {
                    int n = 0;
                    double aux1;
                    string[] aux = new string[n];
                    auxiliar = Interaction.InputBox("Insira os valores", "Vendas");
                    if (!Double.TryParse(auxiliar, out periodo[i, j]) || periodo[i, j] < 0)
                    {
                        MessageBox.Show("Não pode ter vendas negativas.");
                        j--;
                    }
                    else
                    {
                        lstbxVendas.Items.Add($"Total do mês: {i + 1} Semana: {j + 1} - R$ {auxiliar}");
                    }
                    if (Double.TryParse(auxiliar, out aux1))
                        mes = aux1 + mes;
                }
                lstbxVendas.Items.Add($">> Total mês: R$ {mes.ToString("N2")}");
                lstbxVendas.Items.Add("---------------------------------------------------------------");
                geral = mes + geral;
            }
            lstbxVendas.Items.Add($">> Total geral: R$ {geral.ToString("N2")}");
            lstbxVendas.Items.Add("---------------------------------------------------------------");
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            lstbxVendas.Items.Clear();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        double salbruto, salfamilia, salliquido, descINSS, descIRPF, filhos;

        private void BtnSair_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void BtnLimpar_Click(object sender, EventArgs e)
        {
            txtSalL.Text = "";
            txtSalF.Text = "";
            txtNome.Text = "";
            txtIRPF.Text = "";
            txtINSS.Text = "";
            txtDescIRPF.Text = "";
            txtDescINSS.Text = "";
            mskbxSalB.Text = "";
            nupdFilhos.Value = 0;
        }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void BtnVerificar_Click(object sender, EventArgs e)
        {
            if ((Double.TryParse(mskbxSalB.Text, out salbruto)))
            {
                if (salbruto <= 800.47)
                {
                    txtINSS.Text = "7,65%";
                    descINSS = 0.0765 * salbruto;
                    txtDescINSS.Text = "R$ " + descINSS.ToString();
                }
                else
                {
                    if (salbruto <= 1050)
                    {
                        txtINSS.Text = "8,65%";
                        descINSS = 0.0865 * salbruto;
                        txtDescINSS.Text = "R$ " + descINSS.ToString();
                    }
                    else
                    {
                        if (salbruto <= 1400.77)
                        {
                            txtINSS.Text = "9,00%";
                            descINSS = 0.09 * salbruto;
                            txtDescINSS.Text = "R$ " + descINSS.ToString();
                        }
                        else
                        {
                            if (salbruto <= 2801.56)
                            {
                                txtINSS.Text = "11,00%";
                                descINSS = 0.11 * salbruto;
                                txtDescINSS.Text = "R$ " + descINSS.ToString();
                            }
                            else
                            {
                                txtINSS.Text = "Teto";
                                txtDescINSS.Text = "R$ 308.17";
                            }
                        }
                    }
                }
                if (salbruto <= 1257.12)
                {
                    txtIRPF.Text = "-";
                    txtDescIRPF.Text = "Isento";
                }
                else
                {
                    if (salbruto <= 2512.08)
                    {
                        txtIRPF.Text = "15,00%";
                        descIRPF = 0.15 * salbruto;
                        txtDescIRPF.Text = "R$ " + descIRPF.ToString();
                    }
                    else
                    {
                        txtIRPF.Text = "27,50%";
                        descIRPF = 0.275 * salbruto;
                        txtDescIRPF.Text = "R$ " + descIRPF.ToString();
                    }
                }
                filhos = (double)nupdFilhos.Value;
                if (salbruto <= 435.52)
                {
                    salfamilia = 22.33 * filhos;
                    txtSalF.Text = salfamilia.ToString();
                }
                else
                {
                    if (salbruto <= 654.61)
                    {
                        salfamilia = 15.74 * filhos;
                        txtSalF.Text = salfamilia.ToString();
                    }
                    else
                        txtSalF.Text = "0";
                }
                salliquido = salbruto - descINSS - descIRPF + salfamilia;
                txtSalL.Text = "R$ " + salliquido.ToString();
            }
        }

        private void MskbxSalB_Validated(object sender, EventArgs e)
        {

        }
    }
}

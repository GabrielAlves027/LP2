﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.txtDescIRPF = new System.Windows.Forms.TextBox();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtSalL = new System.Windows.Forms.TextBox();
            this.txtIRPF = new System.Windows.Forms.TextBox();
            this.txtDescINSS = new System.Windows.Forms.TextBox();
            this.txtINSS = new System.Windows.Forms.TextBox();
            this.txtSalF = new System.Windows.Forms.TextBox();
            this.nupdFilhos = new System.Windows.Forms.NumericUpDown();
            this.mskbxSalB = new System.Windows.Forms.MaskedTextBox();
            this.btnVerificar = new System.Windows.Forms.Button();
            this.lblNome = new System.Windows.Forms.Label();
            this.lblSalB = new System.Windows.Forms.Label();
            this.lblFilhos = new System.Windows.Forms.Label();
            this.lblINSS = new System.Windows.Forms.Label();
            this.lblIRPF = new System.Windows.Forms.Label();
            this.lblSalF = new System.Windows.Forms.Label();
            this.lblSalL = new System.Windows.Forms.Label();
            this.lblDescINSS = new System.Windows.Forms.Label();
            this.lblDescIRPF = new System.Windows.Forms.Label();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.btnSair = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilhos)).BeginInit();
            this.SuspendLayout();
            // 
            // txtDescIRPF
            // 
            this.txtDescIRPF.Location = new System.Drawing.Point(590, 378);
            this.txtDescIRPF.Name = "txtDescIRPF";
            this.txtDescIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtDescIRPF.TabIndex = 0;
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(219, 51);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(471, 20);
            this.txtNome.TabIndex = 1;
            // 
            // txtSalL
            // 
            this.txtSalL.Location = new System.Drawing.Point(219, 521);
            this.txtSalL.Name = "txtSalL";
            this.txtSalL.Size = new System.Drawing.Size(100, 20);
            this.txtSalL.TabIndex = 2;
            // 
            // txtIRPF
            // 
            this.txtIRPF.Location = new System.Drawing.Point(219, 378);
            this.txtIRPF.Name = "txtIRPF";
            this.txtIRPF.Size = new System.Drawing.Size(100, 20);
            this.txtIRPF.TabIndex = 3;
            // 
            // txtDescINSS
            // 
            this.txtDescINSS.Location = new System.Drawing.Point(590, 308);
            this.txtDescINSS.Name = "txtDescINSS";
            this.txtDescINSS.Size = new System.Drawing.Size(100, 20);
            this.txtDescINSS.TabIndex = 4;
            // 
            // txtINSS
            // 
            this.txtINSS.Location = new System.Drawing.Point(219, 308);
            this.txtINSS.Name = "txtINSS";
            this.txtINSS.Size = new System.Drawing.Size(100, 20);
            this.txtINSS.TabIndex = 5;
            // 
            // txtSalF
            // 
            this.txtSalF.Location = new System.Drawing.Point(219, 450);
            this.txtSalF.Name = "txtSalF";
            this.txtSalF.Size = new System.Drawing.Size(100, 20);
            this.txtSalF.TabIndex = 6;
            // 
            // nupdFilhos
            // 
            this.nupdFilhos.Location = new System.Drawing.Point(219, 163);
            this.nupdFilhos.Name = "nupdFilhos";
            this.nupdFilhos.Size = new System.Drawing.Size(100, 20);
            this.nupdFilhos.TabIndex = 7;
            // 
            // mskbxSalB
            // 
            this.mskbxSalB.Location = new System.Drawing.Point(219, 107);
            this.mskbxSalB.Mask = "99999.99";
            this.mskbxSalB.Name = "mskbxSalB";
            this.mskbxSalB.Size = new System.Drawing.Size(100, 20);
            this.mskbxSalB.TabIndex = 8;
            this.mskbxSalB.Validated += new System.EventHandler(this.MskbxSalB_Validated);
            // 
            // btnVerificar
            // 
            this.btnVerificar.Location = new System.Drawing.Point(219, 225);
            this.btnVerificar.Name = "btnVerificar";
            this.btnVerificar.Size = new System.Drawing.Size(230, 32);
            this.btnVerificar.TabIndex = 9;
            this.btnVerificar.Text = "Verificar Desconto";
            this.btnVerificar.UseVisualStyleBackColor = true;
            this.btnVerificar.Click += new System.EventHandler(this.BtnVerificar_Click);
            // 
            // lblNome
            // 
            this.lblNome.AutoSize = true;
            this.lblNome.Location = new System.Drawing.Point(105, 54);
            this.lblNome.Name = "lblNome";
            this.lblNome.Size = new System.Drawing.Size(108, 13);
            this.lblNome.TabIndex = 10;
            this.lblNome.Text = "Nome do funcionário:";
            // 
            // lblSalB
            // 
            this.lblSalB.AutoSize = true;
            this.lblSalB.Location = new System.Drawing.Point(143, 110);
            this.lblSalB.Name = "lblSalB";
            this.lblSalB.Size = new System.Drawing.Size(70, 13);
            this.lblSalB.TabIndex = 11;
            this.lblSalB.Text = "Salário Bruto:";
            // 
            // lblFilhos
            // 
            this.lblFilhos.AutoSize = true;
            this.lblFilhos.Location = new System.Drawing.Point(124, 165);
            this.lblFilhos.Name = "lblFilhos";
            this.lblFilhos.Size = new System.Drawing.Size(89, 13);
            this.lblFilhos.TabIndex = 12;
            this.lblFilhos.Text = "Número de filhos:";
            // 
            // lblINSS
            // 
            this.lblINSS.AutoSize = true;
            this.lblINSS.Location = new System.Drawing.Point(135, 311);
            this.lblINSS.Name = "lblINSS";
            this.lblINSS.Size = new System.Drawing.Size(78, 13);
            this.lblINSS.TabIndex = 13;
            this.lblINSS.Text = "Alíquota INSS:";
            // 
            // lblIRPF
            // 
            this.lblIRPF.AutoSize = true;
            this.lblIRPF.Location = new System.Drawing.Point(136, 381);
            this.lblIRPF.Name = "lblIRPF";
            this.lblIRPF.Size = new System.Drawing.Size(77, 13);
            this.lblIRPF.TabIndex = 14;
            this.lblIRPF.Text = "Alíquota IRPF:";
            // 
            // lblSalF
            // 
            this.lblSalF.AutoSize = true;
            this.lblSalF.Location = new System.Drawing.Point(134, 453);
            this.lblSalF.Name = "lblSalF";
            this.lblSalF.Size = new System.Drawing.Size(79, 13);
            this.lblSalF.TabIndex = 15;
            this.lblSalF.Text = "Salário Família:";
            // 
            // lblSalL
            // 
            this.lblSalL.AutoSize = true;
            this.lblSalL.Location = new System.Drawing.Point(132, 524);
            this.lblSalL.Name = "lblSalL";
            this.lblSalL.Size = new System.Drawing.Size(81, 13);
            this.lblSalL.TabIndex = 16;
            this.lblSalL.Text = "Salário Líquido:";
            // 
            // lblDescINSS
            // 
            this.lblDescINSS.AutoSize = true;
            this.lblDescINSS.Location = new System.Drawing.Point(500, 311);
            this.lblDescINSS.Name = "lblDescINSS";
            this.lblDescINSS.Size = new System.Drawing.Size(84, 13);
            this.lblDescINSS.TabIndex = 17;
            this.lblDescINSS.Text = "Desconto INSS:";
            // 
            // lblDescIRPF
            // 
            this.lblDescIRPF.AutoSize = true;
            this.lblDescIRPF.Location = new System.Drawing.Point(501, 381);
            this.lblDescIRPF.Name = "lblDescIRPF";
            this.lblDescIRPF.Size = new System.Drawing.Size(83, 13);
            this.lblDescIRPF.TabIndex = 18;
            this.lblDescIRPF.Text = "Desconto IRPF:";
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(509, 225);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 32);
            this.btnLimpar.TabIndex = 19;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.BtnLimpar_Click);
            // 
            // btnSair
            // 
            this.btnSair.Location = new System.Drawing.Point(615, 225);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 32);
            this.btnSair.TabIndex = 20;
            this.btnSair.Text = "Sair";
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.BtnSair_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1313, 615);
            this.Controls.Add(this.btnSair);
            this.Controls.Add(this.btnLimpar);
            this.Controls.Add(this.lblDescIRPF);
            this.Controls.Add(this.lblDescINSS);
            this.Controls.Add(this.lblSalL);
            this.Controls.Add(this.lblSalF);
            this.Controls.Add(this.lblIRPF);
            this.Controls.Add(this.lblINSS);
            this.Controls.Add(this.lblFilhos);
            this.Controls.Add(this.lblSalB);
            this.Controls.Add(this.lblNome);
            this.Controls.Add(this.btnVerificar);
            this.Controls.Add(this.mskbxSalB);
            this.Controls.Add(this.nupdFilhos);
            this.Controls.Add(this.txtSalF);
            this.Controls.Add(this.txtINSS);
            this.Controls.Add(this.txtDescINSS);
            this.Controls.Add(this.txtIRPF);
            this.Controls.Add(this.txtSalL);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.txtDescIRPF);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.nupdFilhos)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox txtDescIRPF;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtSalL;
        private System.Windows.Forms.TextBox txtIRPF;
        private System.Windows.Forms.TextBox txtDescINSS;
        private System.Windows.Forms.TextBox txtINSS;
        private System.Windows.Forms.TextBox txtSalF;
        private System.Windows.Forms.NumericUpDown nupdFilhos;
        private System.Windows.Forms.MaskedTextBox mskbxSalB;
        private System.Windows.Forms.Button btnVerificar;
        private System.Windows.Forms.Label lblNome;
        private System.Windows.Forms.Label lblSalB;
        private System.Windows.Forms.Label lblFilhos;
        private System.Windows.Forms.Label lblINSS;
        private System.Windows.Forms.Label lblIRPF;
        private System.Windows.Forms.Label lblSalF;
        private System.Windows.Forms.Label lblSalL;
        private System.Windows.Forms.Label lblDescINSS;
        private System.Windows.Forms.Label lblDescIRPF;
        private System.Windows.Forms.Button btnLimpar;
        private System.Windows.Forms.Button btnSair;
    }
}

